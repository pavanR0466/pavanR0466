package pages;

import org.openqa.selenium.*;
import org.openqa.selenium.support.*;

public class LoginPage {

    WebDriver driver;

    public LoginPage(WebDriver driver) {
        this.driver = driver;
        PageFactory.initElements(driver, this);
    }

    @FindBy(xpath="//input[@name='username']")
    WebElement username;

    @FindBy(xpath="//input[@name='password']")
    WebElement password;

    @FindBy(xpath="//button[@type='submit']")
    WebElement loginBtn;

    public void login(String user, String pass) {

        System.out.println("Typing username...");
        username.sendKeys(user);

        System.out.println("Typing password...");
        password.sendKeys(pass);

        System.out.println("Clicking login...");
        loginBtn.click();
    }
}
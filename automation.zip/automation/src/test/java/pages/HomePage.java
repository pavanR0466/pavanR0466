package pages;

import org.openqa.selenium.*;
import org.openqa.selenium.support.*;

public class HomePage {

    WebDriver driver;

    public HomePage(WebDriver driver) {
        this.driver = driver;
        PageFactory.initElements(driver, this);
    }
  
   
    @FindBy(xpath="//span[text()='PIM']")
    WebElement pimMenu;

    @FindBy(xpath="//span[text()='Leave']")
    WebElement leaveMenu;

    @FindBy(xpath="//p[@class='oxd-userdropdown-name']")
    WebElement profile;

    @FindBy(xpath="//*[@id=\"app\"]/div[1]/div[1]/header/div[1]/div[3]/ul/li/ul/li[4]/a")
    WebElement logout;

    @FindBy(xpath="//a[text()='Add Employee']")
    WebElement addEmployee;

    @FindBy(name="firstName")
    WebElement firstName;

    @FindBy(name="lastName")
    WebElement lastName;

    @FindBy(xpath="//button[@type='submit']")
    WebElement saveBtn;
    
    @FindBy(xpath = "//span[text()='Buzz']")
    WebElement buzz;
    
    @FindBy(xpath = "//textarea[@placeholder=\"What's on your mind?\"]")
    WebElement text;
 
    @FindBy(xpath = "//button[@type='submit']")
    WebElement postbtn;
    
   public void buzz() {
    	buzz.click();
    	text.sendKeys("Welcome to automation.........................");
    	postbtn.click();
    }
    public void goToPIM() {
        pimMenu.click();
    }
    public void addEmployee() {
        pimMenu.click();
        addEmployee.click();

        firstName.sendKeys("Pavan");
        lastName.sendKeys("RR");

        saveBtn.click();
    }

    public void goToLeave() {
        leaveMenu.click();
    }

    public void logout() {
        profile.click();
        logout.click();
    }
  
}

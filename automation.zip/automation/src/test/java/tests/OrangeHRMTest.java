package tests;

import org.testng.annotations.Test;
import base.BaseTest;
import pages.LoginPage;
import pages.HomePage;

public class OrangeHRMTest extends BaseTest {

    @Test
    public void testFlow() throws InterruptedException {

        LoginPage lp = new LoginPage(driver);
        HomePage hp = new HomePage(driver);
        
        Thread.sleep(2000);

        // Login
        lp.login("Admin", "admin123");
        Thread.sleep(4000);

        // Navigate modules
        hp.goToPIM();
        Thread.sleep(4000);
        hp.addEmployee();
        Thread.sleep(4000);

        hp.goToLeave();
        Thread.sleep(4000);
        
        //dash
        hp.buzz();
        Thread.sleep(4000);

        // Logout
        hp.logout();
    }
}